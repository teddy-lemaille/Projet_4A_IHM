﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Modele_Vue
{
    /// <summary>
    /// Classe abstrait définie pour gagner du temps et ajouter des notifications partout
    /// </summary>
    public abstract class ObjectBase : INotifyPropertyChanged
        {
            public event PropertyChangedEventHandler PropertyChanged;

            /// <summary>
            /// Soulève une notification indiquant que le membre PropertyName est modifié
            /// </summary>
            /// <param name="PropertyName"></param>
            protected internal void OnPropertyChanged(String PropertyName)
            {
                if (this.PropertyChanged != null)
                {
                    this.PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
                }
            }
        }
    }
