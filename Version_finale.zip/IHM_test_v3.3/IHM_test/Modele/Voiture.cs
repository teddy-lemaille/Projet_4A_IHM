﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Modele_Vue;

namespace WpfApp1.Modele
{
    class Voiture:ObjectBase
    {
        private String categorie;
        private int numero;
        private int position;
        private String nomPilote;
        private String nomVoiture;
        private  string[] tabNom=new string[4];
        private String nomEquipe;
        private string dernierTemps;
        private String ecartPrecedent;
        private String ecartLeaderCat;
        private int nbTour;
        private String statut;
        private int posCircuit;
        private int timerCH;
        private int timerI1;
        private int timerI2;
        private UDPListener msg;
        private int numClick;
        private String sector3;
        private String sector2;
        private String sector1;
        private int vitesseMax;
        private String bestSector1;
        private String bestLap;
        private String bestSector2;
        private String bestSector3;

        public Voiture(String a,String n, int num, int pos, String stat, String nomE)
        {
            Categorie = a;
            NomPilote = n;
            Numero = num;
            Position = pos;
            Statut = stat;
            NomEquipe = nomE;
        }

        public string Categorie
        {
            get => categorie; set
            {
                categorie = value;
                OnPropertyChanged("Categorie");
            }
        }
        public int Numero
        {
            get => numero; set
            {
                numero = value;
                OnPropertyChanged("Numero");
            }
        }

        public int NumClick
        {
            get => numClick; set
            {
                numClick = value;
                OnPropertyChanged("NumClick");
            }
        }


        public string NomPilote
        {
            get => nomPilote; set
            {
                nomPilote = value;
                OnPropertyChanged("NomPilote");
            }
        }
        public int Position { get => position; set
            {
                position = value;
                OnPropertyChanged("Position");
            }
        }
        public string Statut
        {
            get => statut; set
            {
                statut = value;
                OnPropertyChanged("Statut");
            }
        }
        public string NomEquipe { get => nomEquipe; set {
                nomEquipe = value;
                OnPropertyChanged("NomEquipe");
            }
        }

        public string NomVoiture { get => nomVoiture; set => nomVoiture = value; }
        public int NbTour
        {
            get => nbTour; set
            {
                nbTour = value;
                OnPropertyChanged("NbTour");
            }
        }

        public string DernierTemps
        {
            get => dernierTemps; set
            {
                dernierTemps = value;
                OnPropertyChanged("DernierTemps");
            }
        }
        public String EcartPrecedent
        {
            get => ecartPrecedent; set
            {
                ecartPrecedent = value;
                OnPropertyChanged("EcartPrecedent");
            }
        }
        public String EcartLeaderCat { get => ecartLeaderCat; set { 
                ecartLeaderCat = value;
                OnPropertyChanged("EcartLeaderCat");
            } 
        }
        public string[] TabNom { get => tabNom; set => tabNom = value; }
        public int PosCircuit { get => posCircuit; set
            {
                posCircuit = value;
                OnPropertyChanged("PosCircuit");
            }

        }

        public int TimerCH { get => timerCH; set
            {
                timerCH = value;
                OnPropertyChanged("TimerCH");
            }
        }
        public int TimerI1 { get => timerI1; set
            {
                timerI1 = value;
                OnPropertyChanged("TimerI1");
            }
        }
        public int TimerI2 { get => timerI2; set
            {
                timerI2 = value;
                OnPropertyChanged("TimerI2");
            }
        }

        public String Sector1
        {
            get => sector1; set
            {
                sector1 = value;
                OnPropertyChanged("Sector1");
            }
        }

        public String Sector2
        {
            get => sector2; set
            {
                sector2 = value;
                OnPropertyChanged("Sector2");
            }
        }
        public String Sector3
        {
            get => sector3; set
            {
                sector3 = value;
                OnPropertyChanged("Sector3");
            }
        }
        public int VitesseMax
        {
            get => vitesseMax; set
            {
                vitesseMax = value;
                OnPropertyChanged("VitesseMax");
            }
        }

        public String BestLap {
            get => bestLap; set
            {
                bestLap = value;
                OnPropertyChanged("BestLap");
            }
        }
        public String BestSector1 {
            get => bestSector1; set
            {
                bestSector1 = value;
                OnPropertyChanged("BestSector1");
            }
        }
        public String BestSector2 {
            get => bestSector2; set
            {
                bestSector2 = value;
                OnPropertyChanged("BestSector2");
            }
        }
        public String BestSector3
        {
            get => bestSector3; set
            {
                bestSector3 = value;
                OnPropertyChanged("BestSector3");
            }
        }

        public Voiture(string categorie, int numero, int position, string nom)
        {
            this.categorie = categorie;
            this.numero = numero;
            this.position = position;
            this.nomPilote = nom;
        }

        public Voiture(string categorie, int numero, int position, string nom, string nomEquipe, string statut)
        {
            this.NomEquipe = nomEquipe;
            this.DernierTemps = DernierTemps;
            this.EcartPrecedent = EcartPrecedent;
            this.EcartLeaderCat = EcartLeaderCat;
            this.Statut = statut;
            Categorie = categorie;
            Numero = numero;
            NomPilote = nom;
            Position = position;
        }

        public Voiture(string msg)
        {
            char[] sep = new char[] { ';' };
            string[] ligne_split = msg.Split(sep, StringSplitOptions.None);

            this.position = Int32.Parse(ligne_split[1]);
            this.numero = Int32.Parse(ligne_split[2]);
            this.nomEquipe = ligne_split[3];
            this.NomVoiture = ligne_split[4];
            foreach(string m in ligne_split )
            {
                Console.WriteLine(m);
            }
            
                if (!ligne_split[5].Equals(""))
                {
                    this.TabNom[0]=(ligne_split[5]);
                }
                if (!ligne_split[6].Equals(""))
                {
                    this.TabNom[1]=(ligne_split[6]);
                }
                if (!ligne_split[7].Equals("")){
                    this.TabNom[2]=(ligne_split[7]);
                }
                if (!ligne_split[8].Equals(""))
                {
                    this.TabNom[3]=(ligne_split[8]);
                }

            this.categorie = ligne_split[10];
            }

        public static int CompareVoiture(Voiture x, Voiture y)
        {
            return x.NbTour.CompareTo(y.NbTour);
        }
    } 
}

