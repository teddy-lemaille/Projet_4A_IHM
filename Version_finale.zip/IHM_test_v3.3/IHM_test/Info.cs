﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IHM_test
{
    public class Info
    {
        private String messageDirection;
        private float temperatureInterne;
        private float temperatureExterne;
        private float humiditeInterne;
        private float humiditeExterne;
        private String meteo;
        private float pressionAtmospherique;
        private DateTime heure;
        private String ventDirection;
        private float ventVitesse;
        private float ventTemperature;
        private float tauxPluieActuel;
        private float tauxPluieHier;
        private double dureCourse  = 21600;

        public string MessageDirection { get => messageDirection; set => messageDirection = value; }
        public float TemperatureInterne { get => temperatureInterne; set => temperatureInterne = value; }
        public float TemperatureExterne { get => temperatureExterne; set => temperatureExterne = value; }
        public float HumiditeInterne { get => humiditeInterne; set => humiditeInterne = value; }
        public float HumiditeExterne { get => humiditeExterne; set => humiditeExterne = value; }
        public string Meteo { get => meteo; set => meteo = value; }
        public float PressionAtmospherique { get => pressionAtmospherique; set => pressionAtmospherique = value; }
        public DateTime Heure { get => heure; set => heure = value; }
        public string VentDirection { get => ventDirection; set => ventDirection = value; }
        public float VentVitesse { get => ventVitesse; set => ventVitesse = value; }
        public float VentTemperature { get => ventTemperature; set => ventTemperature = value; }
        public float TauxPluieActuel { get => tauxPluieActuel; set => tauxPluieActuel = value; }
        public float TauxPluieHier { get => tauxPluieHier; set => tauxPluieHier = value; }
        public double DureCourse { get => dureCourse; set => dureCourse = value; }
    }
}
