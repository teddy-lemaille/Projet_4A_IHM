﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IHM_test
{
    /// <summary>
    /// Logique d'interaction pour PageTest.xaml
    /// </summary>
    public partial class PageTest : UserControl
    {
        public PageTest()
        {
            InitializeComponent();
        }

        private void Soleil_Click(object sender, RoutedEventArgs e)
        {
            Meteo.Source = new BitmapImage(new Uri(@"img/meteo/soleil.png", UriKind.Relative));
        }

        private void Orage_Click(object sender, RoutedEventArgs e)
        {
            Meteo.Source = new BitmapImage(new Uri(@"img/meteo/orage.png", UriKind.Relative));
        }

        private void Pluie_Click(object sender, RoutedEventArgs e)
        {
            Meteo.Source = new BitmapImage(new Uri(@"img/meteo/pluie.png", UriKind.Relative));
        }
    }
}
