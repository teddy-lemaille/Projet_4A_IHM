﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using WpfApp1.Modele_Vue;

namespace IHM_test
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ModeleVue mv;
        private UDPListener udp;

        DispatcherTimer timer;
        TimeSpan time;
        Info i = new Info();


        PageAcceuil vueAcceuil = new PageAcceuil();
        PageRecherche vueRecherche = new PageRecherche();
        PageCircuit vueCircuit = new PageCircuit();
        PageTest vueTest = new PageTest();
        PagePilote vuePilote = new PagePilote();
        public MainWindow()
        {
            InitializeComponent();
            this.Mv = new ModeleVue();
            udp = new UDPListener(Mv);
            vueAcceuil.DataContext = Mv;
            udp.StartListener();

            vueAcceuil.DataGrid.ItemsSource = Mv.C;

            time = TimeSpan.FromSeconds(i.DureCourse);
            timer = new DispatcherTimer(new TimeSpan(0, 0,1), DispatcherPriority.Normal, delegate
            {
                TextBlockHeure.Text = time.ToString("c");
                if (time == TimeSpan.Zero)
                    timer.Stop();
                time = time.Add(TimeSpan.FromSeconds(-1));

            }, Application.Current.Dispatcher);
            timer.Start();

                        
            placeholder.Content = vueAcceuil;
//------------------------------------------------------------------------------------
            pilote.Visibility = Visibility.Visible;
            Test.Visibility = Visibility.Hidden;
        }

        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            Menu.Visibility = Visibility.Hidden;
            CacheMenu.Visibility = Visibility.Visible;
            RectangleMenu.Visibility = Visibility.Visible;
            MenuInfoGeneral.Visibility = Visibility.Visible;
            MenuRecherche.Visibility = Visibility.Visible;
            MenuCircuit.Visibility = Visibility.Visible;

        }

        private void CacheMenu_Click(object sender, RoutedEventArgs e)
        {
            Menu.Visibility = Visibility.Visible;
            RectangleMenu.Visibility = Visibility.Hidden;
            CacheMenu.Visibility = Visibility.Hidden;
            MenuInfoGeneral.Visibility = Visibility.Hidden;
            MenuRecherche.Visibility = Visibility.Hidden;
            MenuCircuit.Visibility = Visibility.Hidden;
        }

        private void Acceuil_Click(object sender, RoutedEventArgs e)
        {
            placeholder.Content = vueAcceuil;
        }

        private void Recherche_Click(object sender, RoutedEventArgs e)
        {
            placeholder.Content = vueRecherche;
        }

        private void Circuit_Click(object sender, RoutedEventArgs e)
        {
            placeholder.Content = vueCircuit;
        }
        private void Test_Click(object sender, RoutedEventArgs e)
        {
            placeholder.Content = vueTest;
        }
        private void Pilote_Click(object sender, RoutedEventArgs e)
        {
            placeholder.Content = vuePilote;
        }


        public string DisplayedImage
        {
            get { return @"H:\\Mes documents\\Appli\\projet 4A\\img\\orage.png"; }
        }
        internal ModeleVue Mv { get => mv; set => mv = value; }
    }
}
