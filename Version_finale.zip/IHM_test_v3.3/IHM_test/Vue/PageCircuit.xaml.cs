﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GrandPrix.Circuits;
using IHM_test.Circuits;
using System.Windows.Threading;
using System.Windows.Media.Animation;

//https://docs.microsoft.com/fr-fr/dotnet/framework/wpf/graphics-multimedia/how-to-animate-an-object-along-a-path-point-animation

namespace IHM_test
{
    /// <summary>
    /// Logique d'interaction pour PageCircuit.xaml
    /// </summary>
    public partial class PageCircuit : UserControl
    {
        PageSuivi vueSuivi = new PageSuivi(); 
        public PageCircuit()
        {
            InitializeComponent();
            placeholder.Content = vueSuivi;         
        }
    }
}
