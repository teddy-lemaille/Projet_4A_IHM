﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Modele;

namespace IHM_test
{
    /// <summary>
    /// Logique d'interaction pour PageTest.xaml
    /// </summary>
    public partial class PageAcceuil : UserControl
    {

        PagePilote vuePilote = new PagePilote();


        public PageAcceuil()
        {
            InitializeComponent();
            

            List<ChampColonneList> champColonneList = new List<ChampColonneList>();



            champColonneList.Add(new ChampColonneList("Collapse", "Cat"));


        }

        private void Click(object sender,MouseEventArgs e)
        {
            DataGrid dg = sender as DataGrid;
            Voiture row = (Voiture)dg.SelectedItem;
            row.NumClick = row.Numero;
            NavigationWindow navWIN = new NavigationWindow();
            navWIN.Content = vuePilote;
            navWIN.Show();
           // Console.WriteLine("ICI : "+row.Numero);
        }


    }

    public class ChampColonneList
    {
        public ChampColonneList(String isVisible, string champColonne)
        {
            IsVisible = isVisible;
            ChampColonne = champColonne;
        }
        public String IsVisible
        { get; set; }
 
        public String ChampColonne
        { get; set; }

       
    }

   


}