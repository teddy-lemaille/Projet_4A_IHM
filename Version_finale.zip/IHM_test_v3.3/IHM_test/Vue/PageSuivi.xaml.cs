﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GrandPrix.Circuits;
using IHM_test.Circuits;
using System.Windows.Threading;



namespace IHM_test
{
    /// <summary>
    /// Logique d'interaction pour PageSuivi.xaml
    /// </summary>
    public partial class PageSuivi : UserControl
    {
        ICircuit circuit = new Circuits.TraceCircuit();
        
        public PageSuivi()
        {
            InitializeComponent();
            ((UserControl)circuit).Visibility = System.Windows.Visibility.Visible;

            var pathData = circuit.TrackPath.Data;
 
            var pathGeometry = pathData.GetFlattenedPathGeometry();

           
            // Create a NameScope for the page so that
            // we can use Storyboards.
            NameScope.SetNameScope(this, new NameScope());

            Canvas myCanvas = new Canvas();
            myCanvas.Width = 800;
            myCanvas.Height = 450;
            myCanvas.Margin = new Thickness(20);

            // Create a Path object to contain the geometry.
            Path myPath = new Path();
            myPath.Fill = Brushes.Blue;
            myPath.Stroke = Brushes.Black;
            myPath.StrokeThickness = 5;

            // Create an EllipseGeometry.
            EllipseGeometry myEllipseGeometry = new System.Windows.Media.EllipseGeometry();
            myEllipseGeometry.Center = new System.Windows.Point(200, 200);
            myEllipseGeometry.RadiusX = 15;
            myEllipseGeometry.RadiusY = 15;

            // Register a name for the geometry so that it can
            // be targeted by animations.
            this.RegisterName("MyEllipseGeometry", myEllipseGeometry);

            // Add the geometry to the Path.
            myPath.Data = myEllipseGeometry;
            myCanvas.Children.Add(myPath);
            this.Content = myCanvas;
            


            // Create a PointAnimationgUsingPath to move
            // the EllipseGeometry along the animation path.
            PointAnimationUsingPath centerPointAnimation = new PointAnimationUsingPath();
            centerPointAnimation.PathGeometry = pathGeometry;
            centerPointAnimation.Duration = TimeSpan.FromSeconds(15);
            centerPointAnimation.RepeatBehavior = RepeatBehavior.Forever;


            // Set the animation to target the Center property
            // of the EllipseGeometry named "AnimatedEllipseGeometry".
            Storyboard.SetTargetName(centerPointAnimation, "MyEllipseGeometry");
            Storyboard.SetTargetProperty(centerPointAnimation, new PropertyPath(EllipseGeometry.CenterProperty));

            // Create a Storyboard to contain and apply the animation.
            Storyboard pathAnimationStoryboard = new Storyboard();
            pathAnimationStoryboard.RepeatBehavior = RepeatBehavior.Forever;
            pathAnimationStoryboard.AutoReverse = true;
            pathAnimationStoryboard.Children.Add(centerPointAnimation);

            // Start the Storyboard when ellipsePath is loaded.
            myPath.Loaded += delegate (object sender, RoutedEventArgs e)
            {
                // Start the storyboard.
                pathAnimationStoryboard.Begin(this);
            };

        }
    }
}
