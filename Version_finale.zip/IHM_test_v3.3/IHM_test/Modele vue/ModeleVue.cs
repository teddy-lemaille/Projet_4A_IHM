﻿using Humanizer;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using WpfApp1.Modele;

namespace WpfApp1.Modele_Vue
{
   class ModeleVue:ObjectBase
    {
        public static object _lock = new object();
        private ObservableCollection<Voiture> c = new ObservableCollection<Voiture>();
        private UDPListener udp;
        


        public ObservableCollection<Voiture> C
        {
            get => c; set
            {
                c = value;
                OnPropertyChanged("C");
            }
        }

        public UDPListener Udp
        {
            get { return udp; }
            set
            {
                udp = value;
                OnPropertyChanged("Udp");
            }
        }
        
        public ModeleVue()
        {                    
            Console.WriteLine("Slt :)");
            BindingOperations.EnableCollectionSynchronization(C, _lock);
        }

        public void CalculEcart()
        {
            List<Voiture> listClasse = C.ToList();
            listClasse.Sort(Voiture.CompareVoiture);

            /*for (int i = 0; i < listClasse.Count; i++)
            {
                Console.WriteLine("maliste classé = " + listClasse[i].NbTour +" posCircuit" + listClasse[i].PosCircuit);
            }*/

            for(int i=0; i<=listClasse.Count-1; i++)
            {
                if(i == listClasse.Count - 1)
                {
                    listClasse[i].Position = 1;
                    listClasse[i].EcartPrecedent = "";
                }
                else
                {
                    if (listClasse[i].NbTour < listClasse[i + 1].NbTour)
                    {
                        listClasse[i].EcartPrecedent = (listClasse[i + 1].NbTour - listClasse[i].NbTour).ToString() + " lap(s)";
                        listClasse[i].Position = listClasse.Count - i;
                    }
                    if (listClasse[i].NbTour == listClasse[i + 1].NbTour)
                    {
                        if (listClasse[i].PosCircuit < listClasse[i + 1].PosCircuit)
                        {
                            listClasse[i].EcartPrecedent = (listClasse[i + 1].PosCircuit - listClasse[i].PosCircuit).ToString() + " lap(s)";
                            listClasse[i].Position = listClasse.Count - i;
                        }
                        if (listClasse[i].PosCircuit > listClasse[i + 1].PosCircuit)
                        {
                            int temp = listClasse[i].PosCircuit;
                            listClasse[i].PosCircuit = listClasse[i + 1].PosCircuit;
                            listClasse[i + 1].PosCircuit = temp;

                            int temp1 = listClasse[i].TimerCH;
                            listClasse[i].TimerCH = listClasse[i + 1].TimerCH;
                            listClasse[i + 1].TimerCH = temp1;

                            int temp2 = listClasse[i].TimerI1;
                            listClasse[i].TimerI1 = listClasse[i + 1].TimerI1;
                            listClasse[i + 1].TimerI1 = temp2;

                            int temp3 = listClasse[i].TimerI2;
                            listClasse[i].TimerI2 = listClasse[i + 1].TimerI2;
                            listClasse[i + 1].TimerI2 = temp3;

                            listClasse[i].EcartPrecedent = (listClasse[i + 1].PosCircuit - listClasse[i].PosCircuit).ToString() + " lap(s)";
                            listClasse[i].Position = listClasse.Count - i;

                        }

                        if (listClasse[i].PosCircuit == listClasse[i + 1].PosCircuit)
                        {

                            switch (listClasse[i].PosCircuit)
                            {
                                case 0:
                                    if ((listClasse[i + 1].TimerCH - listClasse[i].TimerCH) < 0)
                                    {
                                        listClasse[i].EcartPrecedent = TimeSpan.FromMilliseconds(listClasse[i].TimerCH - listClasse[i + 1].TimerCH).Humanize(2);
                                        listClasse[i].Position = listClasse.Count - i;
                                    }
                                    else
                                    {
                                        listClasse[i].EcartPrecedent = TimeSpan.FromMilliseconds(listClasse[i + 1].TimerCH - listClasse[i].TimerCH).Humanize(2);
                                        listClasse[i].Position = listClasse.Count - i;
                                    }
                                    break;
                                case 1:
                                    if ((listClasse[i + 1].TimerI1 - listClasse[i].TimerI1) < 0)
                                    {
                                        listClasse[i].EcartPrecedent = TimeSpan.FromMilliseconds(listClasse[i].TimerI1 - listClasse[i + 1].TimerI1).Humanize(2);
                                        listClasse[i].Position = listClasse.Count - i;
                                    }
                                    else
                                    {
                                        listClasse[i].EcartPrecedent = TimeSpan.FromMilliseconds(listClasse[i + 1].TimerI1 - listClasse[i].TimerI1).Humanize(2);
                                        listClasse[i].Position = listClasse.Count - i;
                                    }
                                    break;
                                case 2:
                                    if ((listClasse[i + 1].TimerI2 - listClasse[i].TimerI2) < 0)
                                    {
                                        listClasse[i].EcartPrecedent = TimeSpan.FromMilliseconds(listClasse[i].TimerI2 - listClasse[i + 1].TimerI2).Humanize(2);
                                        listClasse[i].Position = listClasse.Count - i;
                                    }
                                    else
                                    {
                                        listClasse[i].EcartPrecedent = TimeSpan.FromMilliseconds(listClasse[i + 1].TimerI2 - listClasse[i].TimerI2).Humanize(2);
                                        listClasse[i].Position = listClasse.Count - i;
                                    }
                                    break;
                            }
                        }
                    }
                }

                
            }
        }
         
   }
}
