﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Security.Cryptography;
using WpfApp1.Modele_Vue;
using System.Collections.ObjectModel;
using WpfApp1.Modele;
using System.Windows.Data;
using Humanizer;

namespace WpfApp1.Modele_Vue
{
    //Thread qui reçoit  les messages UDP, et lève des flags pour notifier un nouveau message
    class UDPListener:ObjectBase
    {
        
        private int m_portToListen = 11000;
        private volatile bool listening;
        Thread m_ListeningThread;
        private ObservableCollection<Voiture> vroum;
        private ModeleVue mv;
        

        public ObservableCollection<Voiture> Vroum
        {
            get { return vroum; }
            set
            {
                vroum = value;
                OnPropertyChanged("Vroum");
            }
        }

        //constructor
        public UDPListener(ModeleVue mod)
        {
            this.mv = mod;
            this.listening = false;
        }

        public void StartListener()
        {
            if (!this.listening)
            {
                m_ListeningThread = new Thread(ListenForUDPPackages);
                m_ListeningThread.IsBackground = true;
                this.listening = true;
                m_ListeningThread.Start();
            }
        }

        public void StopListener()
        {
            this.listening = false;
        }

        public void ListenForUDPPackages()
        {
            UdpClient listener = null;
            try
            {
                listener = new UdpClient(m_portToListen);
            }
            catch (SocketException)
            {
                //do nothing
            }

            if (listener != null)
            {
                IPEndPoint groupEP = new IPEndPoint(IPAddress.Any, m_portToListen);

                try
                {
                    while (this.listening)
                    {                        
                        Console.WriteLine("Waiting for UDP broadcast to port " + m_portToListen);                        
                        byte[] bytes = listener.Receive(ref groupEP);
                        String msg = $"{Encoding.ASCII.GetString(bytes, 0, bytes.Length)}";                       
                        Console.WriteLine(msg);
                        string[] ligne_split = msg.Split(';');
                        switch (ligne_split[0])
                        {
                            case "$PI":
                                mv.C.Add(new Voiture(msg));
                                break;

                            case "$CL":
                                int num = Int32.Parse(ligne_split[1]);
                                int nbTour = Int32.Parse(ligne_split[2]);
                                int posCircuit = Int32.Parse(ligne_split[3]);
                                int timer = Int32.Parse(ligne_split[5]);
                                List<Voiture> l = mv.C.ToList();
                                foreach (Voiture v in l)
                                {
                                    //int EcartMini = 100000;
                                    if (v.Numero == num)
                                    {
                                       
                                        v.NbTour = Int32.Parse(ligne_split[2]);   
                                        v.PosCircuit = Int32.Parse(ligne_split[3]);
                                        v.TimerCH = Int32.Parse(ligne_split[5]);
                                        v.TimerI1 = Int32.Parse(ligne_split[6]);
                                        v.TimerI2 = Int32.Parse(ligne_split[7]);
                                        v.Sector1 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[9])).Humanize(2);
                                        v.Sector2 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[10])).Humanize(2);
                                        v.Sector3 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[11])).Humanize(2);
                                        v.BestLap = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[12])).Humanize(2);
                                        v.BestSector1 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[13])).Humanize(2);
                                        v.BestSector2 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[14])).Humanize(2);
                                        v.BestSector3 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[15])).Humanize(2);
                                        v.VitesseMax = Int32.Parse(ligne_split[17]);

                                        v.DernierTemps = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[8])).Humanize(2);
                                        
                                        v.NomPilote = v.TabNom[Int32.Parse(ligne_split[18]) - 1];
                                        if (ligne_split[19].Equals("G"))
                                        {
                                            v.Statut = "Pitlane";
                                        }
                                        else
                                        {
                                            v.Statut = "Running";
                                        }
                                    }
                                    
                                }
                                
                                mv.C = new ObservableCollection<Voiture>(l);

                                break;

                            case "$VI":
                                mv.CalculEcart();
                                break;

                            case "$I1":
                                int numI1 = Int32.Parse(ligne_split[1]);
                                int nbTourI1 = Int32.Parse(ligne_split[2]);
                                int posCircuitI1 = Int32.Parse(ligne_split[3]);
                                int timerI1 = Int32.Parse(ligne_split[5]);
                                List<Voiture> lI1 = mv.C.ToList();
                                foreach (Voiture v in lI1)
                                {
                                    if (v.Numero == numI1)
                                    {
                                        v.Sector1 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[5])).Humanize(2);
                                        v.BestSector1 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[4])).Humanize(2);
                                        v.NbTour = Int32.Parse(ligne_split[2]);
                                        v.PosCircuit = 1;
                                        v.TimerI1 = Int32.Parse(ligne_split[3]);
                                        v.NomPilote = v.TabNom[Int32.Parse(ligne_split[6]) - 1];
                                       
                                    }

                                }
                                mv.CalculEcart();
                                break;

                            case "$I2":
                                int numI2 = Int32.Parse(ligne_split[1]);
                                int nbTourI2 = Int32.Parse(ligne_split[2]);
                                int posCircuitI2 = Int32.Parse(ligne_split[3]);
                                int timerI2 = Int32.Parse(ligne_split[5]);
                                List<Voiture> lI2 = mv.C.ToList();
                                foreach (Voiture v in lI2)
                                {
                                    if (v.Numero == numI2)
                                    {
                                        v.Sector2 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[5])).Humanize(2);
                                        v.BestSector2 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[4])).Humanize(2);
                                        v.NbTour = Int32.Parse(ligne_split[2]);
                                        v.PosCircuit = 2;
                                        v.TimerI2 = Int32.Parse(ligne_split[3]);
                                        v.NomPilote = v.TabNom[Int32.Parse(ligne_split[6]) - 1];

                                    }

                                }
                                mv.CalculEcart();
                                break;

                            case "$CH":
                                int numCH = Int32.Parse(ligne_split[1]);
                                int nbTourCH = Int32.Parse(ligne_split[2]);
                                int posCircuitCH = Int32.Parse(ligne_split[3]);
                                int timerCH = Int32.Parse(ligne_split[5]);
                                List<Voiture> lCH = mv.C.ToList();
                                foreach (Voiture v in lCH)
                                {
                                    if (v.Numero == numCH)
                                    {
                                        v.Sector1 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[8])).Humanize(2);
                                        v.BestSector1 = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[9])).Humanize(2);
                                        v.BestLap = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[4])).Humanize(2);
                                        v.NbTour = Int32.Parse(ligne_split[2]);
                                        v.PosCircuit = 0;
                                        v.TimerCH = Int32.Parse(ligne_split[3]);
                                        v.NomPilote = v.TabNom[Int32.Parse(ligne_split[7]) - 1];
                                        v.DernierTemps = TimeSpan.FromMilliseconds(Int32.Parse(ligne_split[5])).Humanize(2);

                                    }

                                    if (ligne_split[6].Equals("G"))
                                    {
                                        v.Statut = "Pitlane";
                                    }
                                    else
                                    {
                                        v.Statut = "Running";
                                    }

                                    

                                }
                                mv.CalculEcart();
                                break;
                        }    
                        
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                finally
                {
                    listener.Close();
                    Console.WriteLine("Done listening for UDP broadcast");
                }
            }
        }
    }
}