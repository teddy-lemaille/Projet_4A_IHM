﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
/*
namespace WpfApp1.Modele_Vue
{
    class Commande : ICommand
    {
        public event EventHandler CanExecuteChanged;
        private ModeleVue mv;

        public Commande(ModeleVue modv)
        {
            this.mv = modv;
        }
        public bool CanExecute(object parameter)
        {
            return(true);
        }

        public void Execute(object parameter)
        {
          
            Console.WriteLine("Ajouté");
            Console.WriteLine(mv.Course.Count);
        }
    }
}*/
